---
name: Kapadokya Deneyim Platformu
colors:
  surface: '#fef8f4'
  surface-dim: '#dfd9d5'
  surface-bright: '#fef8f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f2ef'
  surface-container: '#f3ede9'
  surface-container-high: '#ede7e3'
  surface-container-highest: '#e7e1de'
  on-surface: '#1d1b19'
  on-surface-variant: '#55433c'
  inverse-surface: '#32302e'
  inverse-on-surface: '#f6f0ec'
  outline: '#88726b'
  outline-variant: '#dbc1b8'
  surface-tint: '#994623'
  primary: '#994522'
  on-primary: '#ffffff'
  primary-container: '#b85d38'
  on-primary-container: '#ffffff'
  inverse-primary: '#ffb59a'
  secondary: '#835418'
  on-secondary: '#ffffff'
  secondary-container: '#fdbd77'
  on-secondary-container: '#784a0d'
  tertiary: '#57614d'
  on-tertiary: '#ffffff'
  tertiary-container: '#707a65'
  on-tertiary-container: '#ffffff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb59a'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7b2f0d'
  secondary-fixed: '#ffdcbb'
  secondary-fixed-dim: '#faba75'
  on-secondary-fixed: '#2b1700'
  on-secondary-fixed-variant: '#673d00'
  tertiary-fixed: '#dce6cd'
  tertiary-fixed-dim: '#bfcab2'
  on-tertiary-fixed: '#151e0e'
  on-tertiary-fixed-variant: '#404a37'
  background: '#fef8f4'
  on-background: '#1d1b19'
  surface-variant: '#e7e1de'
typography:
  display-hero:
    fontFamily: Newsreader
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

### Marka Kimliği ve Felsefesi
Bu tasarım sistemi; Kapadokya'nın binlerce yıllık tüf taşı oyuklarından, vadilere vuran gün doğumu ışığından ve Avanos çömlekçilerinin pişmiş toprak geleneğinden ilham alan organik, editoryal ve rafine bir seyahat rezervasyon ekosistemidir. Dijital soğukluktan ve jenerik acente arayüzlerinden bilinçli olarak uzak durulur. Dokunsal sıcaklık, heykelsi dinginlik ve editoryal dergi estetiği harmanlanarak güven veren, lüks fakat mütevazı bir kürasyon deneyimi sunulur.

### Tasarım Stili: Organik Editoryal Minimalizm
- **Doğallık ve Sıcaklık:** Dijital beyazlar yerine tüf taşının kalkerli kireç tonları; yapay gradyanlar yerine gün doğumu kehribarının kadifemsi ışık kırılmaları.
- **Tipografik Heykelsilik:** Kapadokya peribacalarının ve oyma taş mimarisinin kıvrımlarını yansıtan asil serif başlıklar ile dengelenmiş ultra-okunaklı çağdaş gövde fontu.
- **Mikro Doku ve Dinginlik:** Görsel gürültüden arındırılmış, nefes alan ferah boşluklar, yumuşatılmış taş kesimi sınır hatları ve fiziksel dünyadaki gölge yumuşaklığı.

## Colors

Renk paleti bölgenin jeolojik ve atmosferik katmanlarından damıtılmıştır.

- **Primary (`#B85D38` - Pişmiş Toprak / Terracotta):** Avanos çömlek kili ve gün batımı kanyon duvarlarının temel sıcaklığı. Aksiyon butonları, rezervasyon onayları ve birincil odak noktalarında kullanılır.
- **Secondary (`#DDA15E` - Gün Doğumu Amberi / Bal Sarısı):** Sıcak hava balonlarının altından vuran sabah ışığı. Rozetler, deneyim vurguları, ikincil etkileşimler ve keşif öğelerinde devreye girer.
- **Tertiary (`#58624E` - Ihlara Vadi Yeşili / Adaçayı):** Doğal dengeleyici zeytuni toprak yeşili. Doğa yürüyüşü, ekolojik sertifikalar, vadi rotaları ve rehber onay işaretleri için kullanılır.
- **Neutral (`#1F1D1B` - Derin Bazalt Kömürü):** Bölgenin sert volkanik bazalt taşından gelen kömür siyahı. Metin hiyerarşisi, keskin tipografik kontrast ve premium derinlik sağlar.

### Yüzey ve Fon Renkleri
- **Kalker Taşı Fonu (`#FAF7F2`):** Göz yoran saf beyaz yerine sıcak, hafif kırık tüf yüzeyi.
- **İkincil Konteyner Taşı (`#F2ECE4`):** Kart zeminleri, filtreleme panelleri ve sekme ayrıştırıcıları için tüf oyuğu alt katmanı.
- **Karakteristik Çerçeve Hattı (`#E3D9CC`):** Doğal taş bloklarının derz aralıklarını andıran düşük kontrastlı ayırıcı çizgiler.

## Typography

Başlıklar için **Newsreader**, gövde metinleri ve UI kontrolleri için **Plus Jakarta Sans** kullanılır.

- **Newsreader:** Kitabi, soylu ve heykelsi karakteriyle deneyim başlıklarını bir gezi günlüğü edasıyla sunar. İtalik varyantları, deneyim detaylarında duygu ve derinlik yaratmak amacıyla seçici olarak vurgulanır.
- **Plus Jakarta Sans:** Türkçe karakter desteği kusursuz olan, göz yormayan, hümanist ve açık kavisli yapısıyla rezervasyon akışlarında kusursuz okunabilirlik sunar.
- Hiyerarşide başlıklar düşük kontrastlı değil, Bazalt Kömürü (`#1F1D1B`) ile tam tonda gösterilerek editoryal ciddiyet korunur.

## Layout & Spacing

### Izgara Felsefesi ve Ritim
Tasarım sistemi 12 sütunlu akışkan bir editoryal grid kullanır. Boşluklar birer boş alan değil, vadilerin genişliği gibi kompozisyonun nefes almasını sağlayan yapısal mimari unsurlardır.

- **Masaüstü (1280px ve üzeri):** Maksimum 1320px genişlik sınırında 12 sütun, `2.5rem` dış kenar boşluğu ve `1.5rem` sütun aralığı. Deneyim kartları asimetrik 2'li veya 3'lü kolon gruplarıyla dergi mizanpajı hissi verir.
- **Tablet (768px - 1024px):** 8 sütun, `1.5rem` dış kenar boşluğu ve `1.25rem` oluk genişliği.
- **Mobil (320px - 767px):** 4 sütun, `1.25rem` dış kenar boşluğu ve `1rem` oluk genişliği. Kartlar yatay kaydırma ve dikey editoryal akış arasında dengelenir.

### Dikey Ritim
Bileşen içi boşluklarda `space-md` (16px) ve `space-lg` (24px) standarttır. Bölüm geçişlerinde ise kullanıcıyı aceleye getirmeyen ferah `space-xl` (40px) ve katları tercih edilir.

## Elevation & Depth

Yapay gölgeler ve yapışkan cam yansımaları yerine, Kapadokya'nın doğal güneş açılarından doğan yumuşak ve dağılmış ton katmanları kullanılır.

- **Katmanlı Yüzeyler (Tonal Layering):** Derinlik hissi gölgelerle değil, zemin rengi (`#FAF7F2`) üzerine oturan konteyner tonu (`#F2ECE4`) ve onun da üzerine yerleşen saf oyuk yüzeyleri ile katman katman kurgulanır.
- **Kalker Güneş Gölgeleri:** Yalnızca havada süzülen eylemler (rezervasyon özeti çubuğu, modal pencereler) için sıcak tonlu, aşırı yayılmış ve düşük opaklıklı gölge kullanılır (`rgba(31, 29, 27, 0.06)` ile 24px blur).
- **Taş Derzi Sınırları (Low-Contrast Outlines):** Kartlar ve filtre alanları 1px kalınlığında, mineral dokulu `#E3D9CC` çizgisiyle çerçevelenerek mimari bir netlik kazanır.

## Shapes

Şekil dili, rüzgar ve yağmurun tüf taşlarını aşındırarak oluşturduğu doğal, yumuşak kavisleri yansıtır. Ne jenerik dik köşeler ne de aşırı sentetik kapsüller kullanılır.

- Temel form yarıçapı **0.5rem (8px)** olarak belirlenmiştir; butonlar, giriş alanları ve seçim öğeleri bu ölçüyü temel alır.
- Kartlar, modal pencereler ve öne çıkan görsel bloklar için **1rem (16px)** kavis tercih edilir.
- Etiketler ve arama çubuğu gibi dinamik navigasyon unsurları ise elde tutulan pürüzsüz vadi taşları hissi vermek adına **1.5rem (24px)** kavis ile şekillendirilir.

## Components

### Butonlar (Buttons)
- **Primary:** Terracotta (`#B85D38`) zemin, açık kireç taşı (`#FAF7F2`) tipografi, 8px kavis. Üzerine gelindiğinde derin pişmiş toprağa (`#9C4C2B`) yumuşak geçiş yapar.
- **Secondary / Outline:** 1.5px `#B85D38` çerçeve, zemin şeffaf, metin Terracotta renginde.
- **Subtle / Ghost:** Arka plansız, `#1F1D1B` renkli metin; etkileşimde `#F2ECE4` hafif zemin tonu kazanır.

### Çipler ve Filtreler (Chips)
- Deneyim filtreleri (örn. "Gün Doğumu", "Atlı Safari", "Vadi Yürüyüşü", "Şarap Tadımı") 24px kavisli, `#F2ECE4` dolgulu ve `#E3D9CC` sınırlıdır.
- Aktif çip Terracotta (`#B85D38`) zemin ve kireç beyazı metne bürünür; solunda minimal adaçayı yeşili (`#58624E`) veya amber tonlu ikonlar yer alabilir.

### Deneyim Kartları (Experience Cards)
- 16px kavis, `#FAF7F2` zemin, 1px `#E3D9CC` dış sınır.
- Üstte 4:3 veya 16:10 oranında yüksek çözünürlüklü vadi/aktivite fotoğrafı; görselin sol üstünde yarı saydam kehribar (`#DDA15E`) "Küratör Seçimi" etiketi.
- Başlık Newsreader serifiyle, fiyat ve kişi bilgisi Plus Jakarta Sans ile açıkça vurgulanır.

### Giriş Alanları (Input Fields) & Rezervasyon Seçiciler
- Tarih ve kişi sayısı seçim alanları ferah iç dolgu (`space-md`), 8px kavis ve `#FAF7F2` zemin ile tasarlanır.
- Odaklanıldığında (focus) sınır rengi Terracotta tonuna döner; yumuşak amber halesi ile desteklenir.

### Seçim Elemanları (Checkboxes & Radio Buttons)
- Standart işletim sistemi kutucukları yerine 8px kavisli kare ve dairesel formlar; seçildiğinde Terracotta rengi dolgu ve kireç beyazı tik ikonu taşır.

### Rezervasyon Özeti Çubuğu (Floating Booking Bar)
- Mobil ekranlarda ekranın altına yapışan, hafif kalker gölgeli, hızlı fiyat ve "Yerinizi Ayırın" butonu sunan kompakt etkileşim barı.